import React, {Component} from 'react';
class About extends Component {
    render() {
        return (
        	<div className = "About">
        	This is the about page
        	</div>

        );
    }
}

export default About;