import React from 'react';

const Logo = ()=>(
    <div class={"logo"}>
        <h1 >foodies<sup>np</sup></h1>
    </div>
);

export default Logo;