import React, {Component} from 'react';

class Home extends Component {
  render() {
        return (
        	<div className = "home">
        	This is the home page
        	</div>

        );
    }
}

export default Home;