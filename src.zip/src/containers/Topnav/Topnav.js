import React, {Component} from 'react';
import Logo from "../../component/Logo/Logo";
import { Link } from  'react-router-dom';



class Topnav extends Component {
    render() {
        return (
            <div id={'topnav'} className={"flex-between wrapper"}>
                <Logo/>
                <div className="nav-items flex-between">
                   <div className="nav-item"><Link to="/Home">Home</Link></div>
                    <div className="nav-item"><Link to="/About">About</Link></div>
                    {/*<div className="nav-item"><Link to="/Services">Services</Link></div>*/}
                    <div className="nav-item"><Link to="/Fooditems">Fooditems</Link></div>
                    <div className="nav-item"><Link to="/Contacts">Contacts</Link></div>
                    <div className="nav-item"><Link to="/Login">Login</Link></div>
                </div>
            </div>
        );
    }
}

export default Topnav;