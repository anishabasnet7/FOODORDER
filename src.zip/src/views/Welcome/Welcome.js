import React, {Component} from 'react';

class Welcome extends Component {
    render() {
        return (
            <div>
             This is the welcome page
            </div>
        );
    }
}

export default Welcome;