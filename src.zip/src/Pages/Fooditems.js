import React, {component} from 'react';
class Fooditems extends component{
    render(){
        return (
            <div className = "Fooditems">
                This is the food page
            </div>

        );
    }
}

export default Fooditems;