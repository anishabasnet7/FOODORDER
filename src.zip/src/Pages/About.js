import React, {component} from 'react';
class About extends component {
    render() {
        return (
        	<div className = "About">
        	This is the about page
        	</div>

        );
    }
}

export default About;